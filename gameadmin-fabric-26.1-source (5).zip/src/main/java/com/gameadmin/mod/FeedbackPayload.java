package com.gameadmin.mod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server -> client result of a cast.
 * status CAST: the ability fired, value = how many things it affected (strikes, mobs purged...).
 * status COOLDOWN: refused, value = milliseconds still remaining.
 */
public record FeedbackPayload(int ability, int status, int value) implements CustomPacketPayload {
    public static final int CAST = 0;
    public static final int COOLDOWN = 1;

    public static final CustomPacketPayload.Type<FeedbackPayload> TYPE =
            new CustomPacketPayload.Type<>(GameAdminMod.id("feedback"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FeedbackPayload> CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.INT, FeedbackPayload::ability,
                    ByteBufCodecs.INT, FeedbackPayload::status,
                    ByteBufCodecs.INT, FeedbackPayload::value,
                    FeedbackPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
