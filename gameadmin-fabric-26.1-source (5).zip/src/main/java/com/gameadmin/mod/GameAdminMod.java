package com.gameadmin.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Common entrypoint: registers the network messages, the cast handler and the scheduler. */
public class GameAdminMod implements ModInitializer {
    public static final String MOD_ID = "gameadmin";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static boolean cleaned = false;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.serverboundPlay().register(CastRequestPayload.TYPE, CastRequestPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(FlightTogglePayload.TYPE, FlightTogglePayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(FeedbackPayload.TYPE, FeedbackPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(FlightStatePayload.TYPE, FlightStatePayload.CODEC);

        PayloadTypeRegistry.serverboundPlay().register(Payloads.Power.TYPE, Payloads.Power.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(Payloads.Rule.TYPE, Payloads.Rule.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(Payloads.RunCommand.TYPE, Payloads.RunCommand.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(Payloads.CommandBlockEdit.TYPE, Payloads.CommandBlockEdit.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(Payloads.PassiveToggle.TYPE, Payloads.PassiveToggle.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(Payloads.PassiveState.TYPE, Payloads.PassiveState.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(Payloads.Adapt.TYPE, Payloads.Adapt.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(Payloads.Notice.TYPE, Payloads.Notice.CODEC);

        // These run on the server thread.
        ServerPlayNetworking.registerGlobalReceiver(CastRequestPayload.TYPE,
                (payload, context) -> AbilityManager.handleCast(context.player(), payload.ability()));
        ServerPlayNetworking.registerGlobalReceiver(FlightTogglePayload.TYPE,
                (payload, context) -> FlightManager.set(context.player(), payload.enable()));

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Power.TYPE,
                (payload, context) -> Powers.power(context.player(), payload.id()));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.Rule.TYPE,
                (payload, context) -> Powers.rule(context.player(), payload.rule(), payload.value()));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.RunCommand.TYPE,
                (payload, context) -> Powers.command(context.player(), payload.command()));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.CommandBlockEdit.TYPE,
                (payload, context) -> Powers.editCommandBlock(context.player(),
                        payload.x(), payload.y(), payload.z(), payload.command(), payload.flags()));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.PassiveToggle.TYPE,
                (payload, context) -> Passives.toggle(context.player(), payload.id()));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!cleaned) {          // remove effect entities left behind by a crash or a stopped server
                cleaned = true;
                WorldVfx.cleanup(server);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(Scheduler::tick);
        ServerTickEvents.END_SERVER_TICK.register(Passives::tick);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(Passives::allowDamage);

        LOGGER.info("Game Administrator loaded. You are in charge.");
    }
}
