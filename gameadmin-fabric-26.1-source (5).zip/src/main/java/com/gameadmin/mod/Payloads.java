package com.gameadmin.mod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** The extra network messages for powers, rules, the command tools and passives. */
public final class Payloads {
    private Payloads() {}

    // ------------------------------------------------------------ client -> server

    /** Game mode switch (0 survival, 1 creative, 2 adventure, 3 spectator) or tool (4 = give command blocks). */
    public record Power(int id) implements CustomPacketPayload {
        public static final Type<Power> TYPE = new Type<>(GameAdminMod.id("power"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Power> CODEC =
                StreamCodec.composite(ByteBufCodecs.INT, Power::id, Power::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Set a game rule (index into Powers.RULES) on or off. */
    public record Rule(int rule, boolean value) implements CustomPacketPayload {
        public static final Type<Rule> TYPE = new Type<>(GameAdminMod.id("rule"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Rule> CODEC =
                StreamCodec.composite(ByteBufCodecs.INT, Rule::rule, ByteBufCodecs.BOOL, Rule::value, Rule::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Run any command from the in-game command line. */
    public record RunCommand(String command) implements CustomPacketPayload {
        public static final Type<RunCommand> TYPE = new Type<>(GameAdminMod.id("run_command"));
        public static final StreamCodec<RegistryFriendlyByteBuf, RunCommand> CODEC =
                StreamCodec.composite(ByteBufCodecs.STRING_UTF8, RunCommand::command, RunCommand::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /**
     * Edit a command block while in survival.
     * flags: bits 0-1 = type (0 impulse, 1 chain, 2 repeating), bit 2 = conditional, bit 3 = always active.
     */
    public record CommandBlockEdit(int x, int y, int z, String command, int flags) implements CustomPacketPayload {
        public static final Type<CommandBlockEdit> TYPE = new Type<>(GameAdminMod.id("command_block_edit"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CommandBlockEdit> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.INT, CommandBlockEdit::x,
                        ByteBufCodecs.INT, CommandBlockEdit::y,
                        ByteBufCodecs.INT, CommandBlockEdit::z,
                        ByteBufCodecs.STRING_UTF8, CommandBlockEdit::command,
                        ByteBufCodecs.INT, CommandBlockEdit::flags,
                        CommandBlockEdit::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Toggle a passive (0..4). -1 just asks the server to send the current state. */
    public record PassiveToggle(int id) implements CustomPacketPayload {
        public static final Type<PassiveToggle> TYPE = new Type<>(GameAdminMod.id("passive_toggle"));
        public static final StreamCodec<RegistryFriendlyByteBuf, PassiveToggle> CODEC =
                StreamCodec.composite(ByteBufCodecs.INT, PassiveToggle::id, PassiveToggle::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // ------------------------------------------------------------ server -> client

    /** Bitmask of the passives that are switched on for this player. */
    public record PassiveState(int mask) implements CustomPacketPayload {
        public static final Type<PassiveState> TYPE = new Type<>(GameAdminMod.id("passive_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, PassiveState> CODEC =
                StreamCodec.composite(ByteBufCodecs.INT, PassiveState::mask, PassiveState::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Which mob type you are currently adapting to, and how far along (0 to 5). */
    public record Adapt(String mob, int level) implements CustomPacketPayload {
        public static final Type<Adapt> TYPE = new Type<>(GameAdminMod.id("adapt"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Adapt> CODEC =
                StreamCodec.composite(ByteBufCodecs.STRING_UTF8, Adapt::mob, ByteBufCodecs.INT, Adapt::level, Adapt::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** A short message for the player's screen. */
    public record Notice(String text, int rgb) implements CustomPacketPayload {
        public static final Type<Notice> TYPE = new Type<>(GameAdminMod.id("notice"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Notice> CODEC =
                StreamCodec.composite(ByteBufCodecs.STRING_UTF8, Notice::text, ByteBufCodecs.INT, Notice::rgb, Notice::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}
