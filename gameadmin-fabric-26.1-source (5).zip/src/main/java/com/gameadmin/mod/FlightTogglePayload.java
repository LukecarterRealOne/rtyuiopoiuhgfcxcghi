package com.gameadmin.mod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: turn flight on or off. */
public record FlightTogglePayload(boolean enable) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<FlightTogglePayload> TYPE =
            new CustomPacketPayload.Type<>(GameAdminMod.id("flight_toggle"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FlightTogglePayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, FlightTogglePayload::enable, FlightTogglePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
