package com.gameadmin.mod.client;

import com.gameadmin.mod.Ability;
import com.gameadmin.mod.FeedbackPayload;
import com.gameadmin.mod.Passives;

/** Client-side memory: when each ability is ready again, what was cast last, and whether flight is on. */
public final class ClientState {
    private ClientState() {}

    public static final long[] COOLDOWN_END = new long[Ability.ALL.length];
    public static int lastCast = -1;
    public static boolean flightOn = false;

    /** Bitmask of enabled passives, as last sent by the server. */
    public static int passiveMask = 0;
    /** The mob type you are adapting to (an id like "zombie"), and how far along (0 to 5). */
    public static String adaptMob = "";
    public static int adaptLevel = 0;

    public static boolean passiveOn(int passive) {
        return (passiveMask & (1 << passive)) != 0;
    }

    public static boolean adaptationActive() {
        return passiveOn(Passives.ADAPT);
    }

    public static long remainingMs(int ability) {
        return Math.max(0L, COOLDOWN_END[ability] - System.currentTimeMillis());
    }

    public static void onFeedback(FeedbackPayload p) {
        if (p.ability() < 0 || p.ability() >= Ability.ALL.length) return;
        Ability a = Ability.ALL[p.ability()];
        long now = System.currentTimeMillis();
        if (p.status() == FeedbackPayload.CAST) {
            COOLDOWN_END[p.ability()] = now + a.cooldownMs;
            Vfx.start(p.ability(), p.value());
        } else {
            COOLDOWN_END[p.ability()] = now + p.value();
            Vfx.toast(a.label + " is recharging", a.rgb);
        }
    }

    public static void onFlight(boolean on) {
        flightOn = on;
        Vfx.toast(on ? "Flight engaged" : "Flight off", 0x7FE8FF);
    }
}
