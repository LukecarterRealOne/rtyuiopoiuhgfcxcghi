# Game Administrator (Fabric, Minecraft 26.1)

You are the **game administrator**. Press **G** for the Admin Console (17 abilities, powers and passives).
**V** repeats your last ability. **H** toggles flight. All keys can be changed under Controls -> Game Administrator.

| # | Ability | What it does | Cooldown | Screen VFX (no particles) |
|---|---------|--------------|----------|---------------------------|
| 1 | Smite | Lightning on hostile mobs within 28 blocks (or where you look) | 8s | white flash, jagged bolt |
| 2 | Blink | Teleport to where you look, up to 40 blocks | 3s | cyan speed lines, tunnel vignette |
| 3 | Time Warp | Flip day / night | 5s | gold tint, clock rings, spinning hands |
| 4 | Weather | Cycle clear / rain / thunder | 5s | cold wash, sweeping band, streaks |
| 5 | Full Restore | Full health + hunger, clears bad effects | 10s | green wave, swelling cross |
| 6 | God Mode | 20s invulnerability, regen, absorption | 45s | pulsing gold frame + countdown |
| 7 | Skyward | Launch up, then glide down safely | 6s | upward streaks, white-out |
| 8 | Freeze Field | Freeze + highlight mobs within 24 blocks (10s) | 20s | frosted corners, icy edges |
| 9 | Purge | Delete hostiles within 48 blocks (bosses spared) | 30s | red flicker, scanline, glitch bars |
| 10 | **Time Stop** | Stops time for 8s. Everything freezes except players | 45s | washed-out screen, frozen clock, contracting ring |
| 11 | **Send: Nether** | Sends other players (64 blocks) + hostile mobs (24 blocks) to the Nether. Nobody near? Sends YOU | 15s | red tunnel into a white flash |
| 12 | **Send: End** | Same, to the End (main island) | 15s | purple tunnel into a white flash |
| 13 | **Send: Overworld** | Same, to the Overworld surface | 15s | green tunnel into a white flash |
| 14 | **Overdrive** | 30s speed, strength, haste, jump boost | 40s | orange streaks, heat bands |
| 15 | **Omniscience** | Highlights everything within 64 blocks (15s) + night vision (60s) | 25s | green radar sweep + scanlines |
| 16 | **Zero-G** | Everything within 24 blocks (except you) floats up for 4s, then crashes down | 20s | violet inversion, rising chevrons |
| 17 | **Black Hole** | Opens a black hole where you look. For 6s it drags in every living thing within 26 blocks (except you), crushes what reaches the core, then collapses in a blast | 40s | spiralling arms, black core, accretion rings, white collapse flash |

**Abilities hit EVERYTHING alive near you except yourself** (animals, villagers, monsters, other players). Smite strikes all of
them, Purge deletes mobs and kills players, Freeze/Zero-G/Send/Black Hole affect them all. Only armor stands are skipped.

## Powers tab (G, then "Powers")
- **Game mode:** Survival / Creative / Adventure / Spectator buttons.
- **Game rules:** ON / OFF for Keep Inventory, Mob Griefing, Day Cycle (`advance_time`), Weather (`advance_weather`),
  Fall Damage, Fire Damage, Immediate Respawn and Command Blocks (`command_blocks_work`).
  Uses the snake_case rule names of 1.21.11 / 26.x.
- **Command Line:** type any command and run it, even in survival without cheats. `@s` and `~` refer to you.
- **Command blocks in survival:** press "Get Command Blocks", place one, then **right-click it** (not sneaking) to open
  an editor with the command, type (impulse / chain / repeat), conditional and always-active. In creative you still get
  the normal vanilla screen. Make sure the "Cmd Blocks" rule is ON.

## Passives tab (G, then "Passives")
| Passive | Effect |
|---------|--------|
| Hazard Immunity | Immune to fire, lava, drowning, falls, explosions, lightning, freezing, cactus, berries, suffocation, wither; clears poison, nausea, blindness, hunger |
| **Adaptation** | Learns from ANY damage: mobs, other players, lava, fire, falling, drowning, explosions, cactus, the void... Each hit of a kind raises your adaptation to it (max 5). Each level = 20% dodge, so **level 5 = 100% dodge**. A **top-left HUD badge** shows a Minecraft block emblem, the face (or damage icon), its name and the adaptation bar |
| Night Eyes | Permanent night vision |
| Never Hungry | Hunger never drops |
| Regeneration | Constant slow healing |

## Who can use the powers?
Single player and LAN worlds: everyone in the world. **Dedicated servers:** only players listed (one name per line)
in `config/gameadmin-admins.txt`, which is created on first use. Everyone else sees "Admins only".

## Flight (press H)
Real creative-style flight with a faster speed. While flying you **glow** (others see it too) and your screen
shows a **winged HUD**: flapping feathered wings, speed streaks that scale with your speed, a cyan edge glow and an
ALT / SPD readout. Press H again to land (you get a few seconds of slow falling).

## Two layers of VFX, zero particles
1. **Screen VFX** (only the caster sees these): flashes, vignettes, streaks, scanlines, glitch bars, drawn on the HUD.
2. **World VFX** (EVERYONE nearby sees these, server-side): glowing block-display entities that are spawned, animated
   and removed again, plus a sound for every ability:
   - Smite: white beams + shock rings on every struck mob
   - Blink: cyan gate collapsing where you left and bursting where you arrive
   - Time Warp: purple (to night) or gold (to day) rings and a rising column
   - Weather: a cloud slab overhead with falling rain streaks
   - Full Restore: lime column rising from your feet
   - God Mode: golden shell burst, then a pulse ring at your feet every 2s for 20s
   - Skyward: huge beam into the sky
   - Freeze Field: an ice block around every frozen mob until it thaws
   - Purge: red beams on every removed mob + two big shock rings
   - Time Stop: a giant glass bubble around you for the whole freeze
   - Send: dimension-coloured column on each target, and an arrival ring where they land
   - Overdrive: three orange rings spiralling in as they rise
   - Omniscience: huge green scan rings
   - Zero-G: magenta columns on every lifted mob
   - Flight on/off and Adaptation dodges also flash a ring + sound
   Leftover effect entities (after a crash) are removed on the next server start.

If the world ever stays frozen after Time Stop, run `/tick unfreeze`.

## If world effects (rings, beams, bubbles) do not appear
Open `logs/latest.log` and search for `Command rejected by the parser`. Every effect command that the game refuses is
logged there with the reason. Send those lines along and the effect can be fixed.

## Install
Minecraft **26.1.x**, **Fabric Loader 0.19.3+**, **Fabric API**, Java 25.
Put the jar in `mods/`. For multiplayer, install it on the server and every client.
Any player with the mod can use the abilities, so this is meant for single player or friends.

## Build on GitHub
Upload this folder to a repo. Actions tab -> "Build mod" -> download the `gameadmin-26.1-fabric` artifact.
Needs JDK 25 and Gradle 9.7 (the workflow sets both up).
